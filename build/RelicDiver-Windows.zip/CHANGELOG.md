# Local build history

## 34 — Handheld readability and camera preferences

- Options now offers a device-local Standard / Handheld UI preset, independent Standard / Large minimap, and Standard / Close camera framing. Desktop defaults and existing settings keep their original view. Fresh Android installs use the handheld UI and larger map.
- Handheld layouts use larger text, taller title actions, wider upgrade cards, clearer prompts and more room for Workshop descriptions. Options rows remain reachable, account and purchase controls fit, and map markers grow with the larger minimap. Fixed unsupported arrow glyphs in the upgrade overlay.
- Close framing is optional and keeps the existing collision and lock-on path; FOV, combat rules, account progress and co-op loadouts are unchanged. Preferences persist on each device/browser. Physical controller, Retroid readability and owner playtest remain pending.

## 33 — Review Workshop purchases before spending

- Selecting an available circuit or specialization opens a purchase review with its original digger portrait, effect, cost and wallet before/after. Cancel is selected first. A fresh Confirm spends; Back returns to the exact node. Held input and the opening double click cannot buy accidentally.
- Guest purchases keep the existing atomic save and rollback on failure. Account purchases show confirmed, refused or pending results; Close does not cancel a submitted purchase, and Retry Sync reuses its existing operation. Equipping an owned specialization remains immediate and free.
- Validation: purchase review 63, account 56, progression 310, UI 93 and Options 43 checks pass. Disposable browser checks cover Guest save/reload, held input and account retry/conflict behavior, plus desktop and 960×540 captures. No server, API, prices, progression or protocol changes. Physical controller, Retroid and owner playtest remain pending.

## 32 — Upgrade overlays and queued co-op choices

- Part, level and guardian-milestone choices now appear over the same camera view with a brief fade, cobalt dim and the Life/map/team HUD kept visible. Solo pauses; Back or the parts button returns an unused offer to pending.
- Online, every earned choice waits until opened with Tab / Select. Picks advance in one overlay, with a fresh press for each. Your digger stands still while choosing; combat continues and hits can land. Downing closes the overlay and keeps unused offers. Unpicked upgrades expire at final extraction.
- Exact offers survive reload and host migration without rerolls or duplicate rewards. Fixed an intermediate recovery snapshot that could include a closed or already-applied offer.
- Validation: overlay 248, co-op feedback 60, resume 31, milestone 59 and readiness 57 checks pass. Real signed-in two-browser co-op verified four queued offers, held input, Back/reload, final-pick/reload and host migration against a disposable account service. Ordinary Web menus/Ready/cancel/reload and pointer-capture checks pass. Physical controller, Retroid and owner playtest remain pending.

## 31 — Deliberate Solo selection and confirmed co-op starts

- Main-menu actions now include Account / Sign in. Solo opens a preparation screen with the original digger model, signature attack and equipped specialization. Accept the digger, then press again to start; Back restores useful focus. Held buttons and an idle mouse no longer activate the next screen or steal controller focus.
- Every online player confirms their loadout with Ready. The host starts a cancellable countdown, then everyone prepares the same dig before it begins together. Changing a loadout clears consent. Account delays, cancellation and retries retain the existing unplayed lease without starting the dig early.
- Existing Guest/sign-in, Workshop navigation, invites, late join, reconnect and host migration remain supported. Game protocol is now 11: refresh older browser tabs and update native clients before joining current lobbies. The published Android 0.19.0 APK remains an older client; a matching Android release is pending.
- Validation: UI 93, Options 43, account 56, readiness 57, resume 24 and relay 41 checks passed; real two/four-client readiness, seven-role recovery and two-browser Ready/cancel/reload journeys passed. Physical controller and Retroid checks remain pending.

## 30 — In-game sign-in and one rule for Guest progress

- Signing in no longer leaves the game. The account bar opens a panel over the title on browser, Windows and Android: email and password, then a 6-digit authenticator code (or a backup code) if the account uses one. Create an account or ask for a password reset from the same panel. Errors (wrong password, unconfirmed email, too many attempts, no connection) appear in the panel. Windows and Android no longer use the device code approved in a separate browser.
- Guest progress: creating an account (or signing in to an empty one) moves this device's Guest progress into it automatically, and play continues there. Signing in to an account that already has progress keeps the account's progress and discards this device's Guest progress, including a saved Guest dig. Signing out starts a fresh Guest.
- Opening an invite link while signed out shows the sign-in panel; after signing in, the game joins that lobby.
- Android 0.19.0 (code 5) includes all of this plus builds 26–29; it installs over earlier test builds and keeps their saves. Older Android builds still sign in with a device code, but can't join current lobbies.
- Checks: account 56, Android 48, UI 47, options 39, progression 309, resume 24, co-op feedback 40, smoke and persistence; the account end-to-end test against a disposable database with password + authenticator sign-in on native and in a real browser, lost responses, reload, second browser and Windows sync.

## 29 — Polish P7 animation and movement

- **Dash you can see.** Each digger now has four dash animations (forward, back, left, right): a crouch, a strong lean into the dash, then a foot plant and settle. The dash picks the one matching its direction relative to where you face, starts on the first frame and kicks up a ring of dust. Running, jumping or getting hit cuts the recovery short; controls and dash timing are unchanged. Teammates' dashes show the right direction too, worked out from their movement, so co-op protocol is unchanged.
- Dash invulnerability no longer blinks the model (that blinking hid most of the old dash), and dashing can no longer shorten the longer invulnerability after a hit or revive.
- **Planted running.** Mega, Roll and Tron's run and backpedal now plant each boot on the floor while the body passes over it: heel-to-toe roll, knee drive, a brief airborne moment between steps and a forward lean (the old run leaned slightly back). Before, boots skated at roughly two thirds of the running speed. Servbot keeps his waddle. Strafing is unchanged.
- Light stick tilts slow the stride cadence to match the slower movement.
- **Landing.** Landing from a real fall (not a short hop) squashes into the knees, then rises back to idle. Moving on skips it, so control stays immediate.
- Checks: character 8692 (dash direction, onset, recovery, steady buster aim, remote dashes, landing, planted boots that don't skate or sink), combat, milestones, movement, smoke and the multi-process co-op test. Contact sheets and game-camera footage reviewed for all four diggers.

## 28 — Polish P6 guardian milestones

- The first and second guardians give each digger a personal milestone: a choice of three major upgrades lasting the rest of the dig. Offers are weighted toward fitted parts, but every milestone works without them. Ten milestones: Arc Conductor (lightning chains), Wildfire Core (burns that spread on kills), Glacier Drive (dash slows nearby machines), Twin Capacitor (+35% second-bolt chance), Fortune Prism (+15% crits that triple), Bulwark Frame (-25% damage above half Life), Scavenger's Instinct (repair and part chance on kills), Opening Salvo (+35% against healthy machines), Second Wind (survive one downing hit per descent) and Kinetic Loader (+30% fire rate after dashing). Values are tuning proposals.
- The final guardian ends the dig, so it keeps its part reward and gives no milestone. Regular parts and level-ups are unchanged.
- In co-op, each client grants its own player's milestone once it sees the guardian fall. Picks can be put aside like cache picks. Builds and checkpoints carry taken and waiting milestones; offers are seeded per dig, descent and digger, so a rejoin sees the same three. Duplicates are impossible and every dig starts without milestones. Co-op protocol 10.
- Checks: new milestone checks 59 (catalogue, weighting, grant once per guardian, final-guardian rule, deferral, rejoin, forged builds, effects, reset), every existing client suite, the multi-process co-op test (now also checking that host and guest each get their own milestone), and a live-dig soak with every milestone.

## 27 — Polish P5 character specializations

- Each digger's grid ends in two specialization circuits (600 Zenny each). Owning one unlocks it; equip one in the Workshop for the next dig, and switch freely between digs. With none equipped, the dig uses the default loadout. Only the equipped specialization applies, even with both owned.
- Mega: Focus Lens / Ricochet Coil. Roll: Field Medic / Needle Storm. Tron: Siege Breaker / Wide Barrage. Servbot: Demolition Charge / Scrap Runner. Each works solo; Field Medic and Needle Storm's exposure also help teammates. Values are tuning proposals.
- The equipped specialization is saved per device in settings, carried in the dig's build, and restored exactly on co-op rejoin and checkpoint resume; builds cannot claim one the digger doesn't own. The title shows the equipped specialization next to the signature attack.
- Profile 4 (grid gains `spec_a`/`spec_b`), co-op protocol 9. Stagger and slow effects reach the host through the existing slow message, which now carries a radius.
- Checks: progression 309 (equip rules, one-per-dig, build round trip, Focus ramp, Needle Storm exposure, Field Medic reach, Ricochet bounce, blast radius and guardian bonus), the other client suites, server 43 against PostgreSQL, and a live-dig soak firing every digger with each specialization.

## 26 — Polish P4 Workshop circuit grids

- The Workshop list is now a connected 12-circuit grid per digger. Buy Reinforced Frame, then any circuit linked to one you own. Routes branch and rejoin, and every circuit is reachable, so each grid can reach 100%.
- Seven new modest circuits: Shock Plating, Dash Servos, Tuned Barrel, Scrap Magnet, Quick Loader, Reserve Cell and Signature Circuit II (Mega: every fourth Pulse shot is charged; Roll: dash repairs 12 Life; Tron and Servbot: 5.2 m blasts). A full grid costs 3,120 Zenny. Prices and values are tuning proposals.
- Old purchases carry over unchanged, with no refunds or charges. The original five circuits keep their ids and effects, and their links keep every earlier tree valid. Guest saves, save codes and account profiles all upgrade to profile 3.
- The grid has owned/available/short/not-linked states, a details panel with links and cost, a completion bar, zoom and recenter buttons, mouse drag/wheel and keyboard/controller navigation. Arrows/D-pad move to the nearest circuit in that direction, and Up/Down at the edges reach the digger headers and the bottom buttons.
- The account server applies the same grid rules to purchases (`server/accounts/rules.js`, checked against the game's copy by tests). Co-op protocol 8, so mixed old/new builds cannot share a lobby. Checkpoint format unchanged.
- Checks: progression 260 (grid routes, purchases, migration, effects, zoom), UI 47, options 39, account 37, Android 49, character, combat, co-op 40, resume 24, audio 66, smoke/movement/persistence/combat; server 43 including account API purchases against PostgreSQL.

## 25 — Polish P3 music

- All seven cues re-arranged around their unchanged melodies and chords. Each cue now builds through intro, full band, call-and-response and climax sections.
- Each cue has its own groove, comping, voice-led chords, moving bass lines with approach notes, rotating drum fills, harmony lines and colour instruments (strings, flute, harp, woodwinds, timpani, crystal arpeggios).
- Phrase dynamics, light humanisation, per-instrument reverb and per-cue mixes. Loudness matches the old cues, so the music/effects balance is unchanged.
- Extraction and defeat stingers have fuller endings. Sound effects and ambience are unchanged.
- Checks: audio 66, audio data validator (8 Ogg files, 29 effects, loop seams, captured in-game mix with no clipping), melody-identity check. The owner listened and approved.

## 24 — Workshop controller navigation

- The Workshop has three rows. On the digger headers, Left/Right moves between diggers and Down enters that digger's skills. Up from the top skill returns to the selected header instead of jumping to another digger. On the bottom buttons, Left/Right moves between Save Codes, Start and Back. LB/RB always switch digger.
- The selected header is highlighted with a portrait and yellow name; the focused header shows the cursor.
- Skill buttons say why you can't buy: `Locked` (requirements), `Need N Z` (Zenny) or `Syncing` (account not yet synced).
- Checks: progression 153 (D-pad row navigation), UI 47, options 39.

## 23 — Polish P1 UI fixes and P2 ruins

- Workshop opens on a skill: the first affordable node, else the first unfitted one. Left/Right, the stick and LB/RB (or C/Y) switch diggers and refocus that digger's tree.
- Title Credits no longer overlaps the Dig Record panel. The account button and caption show Guest, checking, signing in, restoring/offline, signed in with sync status, or sign-in needed. Stale session checks are ignored and long names are trimmed.
- Archive, Garden and Core now have their own painted palettes, lamp tints and machinery panels. Ceramic wall bands, floor seals and a twelve-emblem room crest atlas are drawn on existing walls and cover. Painted surfaces are matte.
- No new lights or colliders. Seeded layouts, RNG, colliders, interactables and enemy spawns match the previous build for four seeds × three descents. Native renders use about 15% fewer draw calls per descent, with frame time no worse.
- Tests that set their own save/checkpoint paths keep them again. Since the Android build, startup replaced those paths, so progression and other checks could overwrite the desktop `save/archive.json`.
- Game protocol 7, checkpoint 3 and profile 2 are unchanged. The Android test APK (code 4) was not rebuilt and does not include these visual changes yet.
- Checks: UI 47, options 39, account 37, progression 146 (8 new Workshop/account checks), character, combat, resume 24, movement, persistence and smoke. Rooms from all three descents and the title/Workshop at 1440×900 and 960×600 were rendered for review.

## 22 — Owner dashboard and account readiness fixes

- Read-only owner dashboard at `/admin`: live players and lobbies, daily/weekly/monthly active accounts, registrations, logins by method, account digs, digger usage, platforms, versions and sync health, plus player search and detail. Owner only, with an authenticator app; emails masked in lists. Detailed records kept 30 days, activity 90 days, daily summaries 12 months; no IP addresses or device fingerprints.
- Account digs report foreground play time every two minutes (an estimate; never queued with progress).
- Android: choosing Guest while a saved sign-in is still being restored offline keeps the sign-in; restores retry by themselves; a bad server profile no longer leaves a half signed-in state; a browser that fails to open keeps the update prompt.
- Android test APK code 4, version 0.18.1. Game protocol 7, checkpoint 3, profile 2 unchanged.
- Checks: server 41/41 (6 dashboard), account 37, Android 49, UI 47, resume 24, smoke.

## 21 — Android accounts and startup updates (local, not deployed)

- Android device-code sign-in, origin-isolated Keystore-encrypted sessions, startup recovery, suspension-safe outbox/checkpoints and wall-clock device-code expiry. No persistent plaintext tokens.
- Startup update metadata with integer version codes, optional/required online update choices and explicit system-browser downloads; immutable local APK staging with checksums/signing fingerprints and opt-in server routes. Nothing published live.
- Controller-accessible Credits / Licenses with full engine, asset, audio and font notices. Android test APK code 3, version 0.18.0; game protocol remains 7.
- Client Android 44, account 34 and UI 47 checks; server update/relay 10 tests; native emulator Keystore encryption/tamper/sign-out/process restart/in-place upgrade passed. Retroid cross-play and installer failure cases remain unverified.

## 20 — Game account sync (deployed with authorization)

- Browser cookie sign-in and Windows device-code sign-in, with cobalt account menus and controller navigation. Windows credentials stay in memory; no plaintext token files.
- Separate Guest/account profiles and durable account outboxes. Results retry without duplicate rewards, pending Zenny cannot be spent, purchases use server revisions, and guest adoption requires preview/confirmation into an empty account.
- Online account run starts, explicit takeover, lease heartbeats, account-owned checkpoints, and fresh lobby tickets on every connection. Guest identity stays separate. Game protocol remains 7.
- Checks: 34 account client checks; progression 138, resume 24, co-op feedback 40, UI 47, Options 39; smoke and reconnect/host-migration/server-restart suites; server 34/34 with PostgreSQL; real Godot HTTP tests with deliberately lost committed responses and signed-in relay identity. Real browser sign-in preserves a pending invite under COOP/COEP; an in-game purchase survives reload and syncs to another browser and Windows.

## 19 — Account server (no game change)

- The server can run player accounts: email sign-up with verification and password reset, Windows/Android sign-in with a code approved in the browser, and a progress API that records run rewards and Workshop purchases exactly once. Off unless configured (`docker-compose.accounts.yml`, docs/ACCOUNTS-OPS.md), with encrypted daily database backups.
- The game doesn't use accounts yet; that's the next update. Guest play, co-op and game protocol 7 are unchanged.

## 18 — Android test build (no gameplay change)

- Native ARM64 Android APK (`tools/package-android.ps1`, app id `dev.galosengen.relicdiver`), landscape, same game and online lobbies as the browser and Windows builds. Verified on the Android emulator only; not yet on the Retroid Pocket 5.
- Saves, settings, audio settings, online identity and checkpoints use per-app storage on Android through `DiverPaths`. Desktop and web storage are unchanged. No gameplay or protocol change: still game protocol 7.

## 17 — Shared co-op map, waiting part picks and cache icons

- **Shared map:** rooms any teammate explores appear on everyone's ruins map; clears were already shared. Room banners still greet you the first time you walk in.
- **Waiting part picks:** when a teammate opens a cache, you get a "Part Choice Waiting" notice instead of the choice screen taking over. **Tab / Select** opens it (and opens Buster parts when nothing is waiting). The pick screen shows your fitted parts. Online, **Tab / Select** or **Esc / B** puts a pick aside for later; the same three parts stay on offer. Waiting picks survive refreshes, rejoins and host migration.
- **Cache icons on the map** for revealed rooms: grey while sealed, gold when ready, flashing cyan while your pick from it waits, dark once opened.
- Game protocol 7: update all co-op clients together. Checkpoint format 3 is unchanged; saved digs from build 16 still restore.

## 16 — Signature attacks, Zenny, Workshop and portable progress

- Four signature attacks: Pulse Mega, rapid/support Roll, heavy/splash Tron, ballistic-bomb Servbot. Servbot gains its own small collision capsule, lower camera, faster movement and 65 base Life.
- Zenny rewards and five purchased skill nodes per digger, including unique signature circuits and part-pool research. New part gates: 40/100/220; existing earned unlocks migrate.
- Versioned, atomic progress saves plus validated, checksummed save-code export/import with a replacement preview. Purchases persist immediately and survive browser reloads.
- Whole-floor or zoomed/scrolling map option. Actual model-rendered Volnutt portrait replaces the loader illustration and Godot favicon, with explicit exported browser icons.
- Fixed browser text-field focus during redraw; online starts/rejoins wait for a real click before pointer lock.
- Game protocol 6 / checkpoint format 3: update all co-op clients together; older active dig checkpoints are incompatible. No live deployment in this branch.


## 15 — Tron Bonne and Servbot

- Two more playable diggers from the user's supplied Mega Man Legends models: **Tron Bonne** and a **Servbot**. Pick them on the title screen (C or Y cycles through all four) or in an online lobby.
- Both use the same twelve authored animations, attached buster, parts and progression as Mega and Roll for now. The Servbot is about half their height and waddles when it runs.
- Old and new builds can't share a lobby; refresh the page to update.

## 14 — Harder machines, a loading screen and an icon

- **Difficulty** (the user had cleared ten digs without being hit):
  - Robots have about 60% more Life and gain 65% per descent instead of 40%. Each chamber holds one more.
  - Every attack hits harder and now scales with depth, including sentry and guardian bolts.
  - Warnings stay, but wind-ups and recoveries are 25% shorter on B1 and 40% shorter on B3. Robots move faster and hostile bolts fly about 60% faster.
  - Sentries and guardians lock their aim just before firing and lead a moving digger; the warning line turns red when it locks.
  - Guardians have about three times the Life, attack faster in overdrive, and shield themselves briefly as overdrive begins so they can't be burst down through it.
- **Loading screen:** the browser build opens on a Relic Diver page with a lock-on spinner around Mega, a Life-gauge progress bar with a percentage, and rotating flavour text. The Godot logo no longer appears at startup.
- **Icon:** the browser tab and the Windows build use a Mega portrait.
- The Broken Foundry's pipes now run overhead instead of across doorways.

## 13 — Bigger, more varied ruins and a proper map

- **Rooms are 50% bigger** (30 m across instead of 20 m, with higher ceilings), and corridors are longer.
- **Hallways fork.** Floors now include passage junctions: some fork three or four ways, some loop back to rooms you've seen, and some dead-end at hidden salvage vessels. Rooms connect only where there is a real corridor.
- **New rooms in the pot,** one of each on every floor alongside the five cover arrangements:
  - **Grand Concourse:** a hall twice the size of a normal room, with a colonnade, a raised dais reached by ramps, and a larger group of machines.
  - **Stepped Vault:** a jump puzzle. Stepping blocks climb to a high ledge with a free hidden cache and salvage.
  - **Terrace Hall:** a raised terrace along one wall with a ramp at each end. Robots take the ramps to follow you up.
- **Ruins map:** now a to-scale plan of the floor. The arrow sits at your exact position and turns with your camera, corridors are drawn where they really run, and teammates show as coloured dots online.
- Attack warnings and blasts follow the floor a robot or its target stands on, so they work on raised ground.
- Old and new builds can't share a lobby (the ruins differ); refresh the page to update.

## 12 — Smoother browser play

- The first shot that lands no longer freezes the browser game for a moment: the hit flash, sparks and damage number are prepared while the floor loads.
- Each room's floor tiles draw as one mesh, so long views down the halls cost roughly 40% fewer draw calls. The ruins look the same.

## 11 — Controller support, Options and Leave Dig

- Full controller support (Xbox-style names; works with any pad Godot recognises):
  - **Play:** left stick moves, right stick looks, RT fires, LT locks on, A jumps, B dashes, X salvages/uses, LB pings, View opens Buster Parts, Start opens the menu, and the D-pad sends callouts.
  - **Menus:** D-pad or left stick moves, A confirms, B goes back, Y switches digger on the title.
  - **Prompts and feel:** button prompts follow the last device used; hits rumble the controller.
- New **Options** menu (title and pause):
  - **Sound:** master, music, effects, ambience, mute.
  - **Display:** fullscreen, camera motion, field of view.
  - **Controls:** mouse sensitivity, controller look speed, invert look, vibration.
  - **Controls & bindings:** rebind every action for keyboard/mouse and controller separately, with automatic swaps on conflicts and a reset to defaults. Settings save to `settings.json` (`audio.json` keeps the volumes).
- **Leave Dig** in the pause menu for everyone, with a second click to confirm. Online, a leaving host hands the dig to the others; the host also has **End Dig for Everyone**.
- Solo digs no longer save mid-run (they're short). Online digs keep their checkpoints so rejoining still works.
- New checks: controller, options, rebinding and leave suite (39). Existing suites pass.

## 10 — Runs that survive mishaps, plus co-op communication

- Host migration: when the host leaves or crashes, the next digger takes over hosting from the world they already see and the dig continues.
- Stable player identity and a mirrored roster of every digger's build: a refresh, crash or rejoin returns the exact build (parts, level, experience, Life, downed state, an unfinished part choice and queued level-ups).
- Automatic reconnection for dropped connections (the dig freezes with a *Reconnecting…* banner for up to 90 seconds). A newer tab replaces an older one cleanly.
- Checkpoints: every machine saves the dig every 5 seconds and on every build change (atomic writes with a backup copy), and the host also stores one on the server. Empty lobbies wait 15 minutes for returning diggers; a dig can also be recreated under its old code after a server restart. Solo digs gain **Continue Dig**.
- Mishap guards: the browser asks before leaving mid-dig; leaving, ending for everyone, removing players and replacing a saved dig need a second click; abandoned digs still count their machines.
- Hardening: protocol versioning (mismatched builds can't share a lobby), shape validation for every network message, and guarded lobby commands.
- Co-op features: spectator camera while down, text chat (lobby and dig), team pings, quick-chat callouts with speech bubbles, host kick, lobby lock and optional lobby passwords.
- New checks: run persistence suite (24), server suite (9), a seven-process network gauntlet (refresh, Wi-Fi drop, host crash, host return, empty-lobby resume, server-restart resume) and browser reload tests.

## 09 — Online co-op in the browser

- Added a web export (Godot threaded WebAssembly build) and a small Node server that hosts it with the required cross-origin isolation headers, pre-compressed downloads and a WebSocket lobby relay. Deployment targets the user's domain through a Cloudflare Tunnel (Docker Compose or Host-Online.cmd).
- Title → **Play Online**: name entry, public/private lobbies, a live lobby browser, join by code, and invite links (`/?lobby=CODE`) that open straight into the lobby. The lobby room shows the party with each digger's character and buster, plus a copy-link button.
- Co-op for up to four diggers in one seeded run. The host simulates robots and loot; each digger controls their own movement, Life and build. Shared scrap and XP, a personal cache pick for everyone, a guardian core per digger, party-scaled robots, downed/revive by standing close, the lift waits for the team, and late joiners sync into a dig in progress.
- Online menus and part choices no longer pause the dig; choosing is protected. Teammate nametags, a team Life panel, revive prompts and a click-to-aim hint for browsers.
- Saves use browser storage on the web; desktop saves are unchanged. The Windows build can join lobbies through **Dig Server**.
- New checks: server tests, a three-instance host/guest/late-join network test, a real-browser lobby test and co-op HUD renders. Existing character, combat, UI, audio, smoke, movement and persistence checks pass.

## 08 — Design documentation and repository handoff

- Added DESIGN.md and focused handoffs for implementation, art/animation, audio/UI, playtesting and repository workflow, plus a concise fresh-instance prompt.
- Updated HANDOFF.md and project instructions to record the user's new authorization for the named GitHub repository.
- Added selective Git exclusions that preserve editable project inputs and licenses while omitting caches, backups, personal saves and raw recordings.
- Packaged the tested Windows runtime, content pack and notices into a portable ZIP; added fresh-clone setup and repeatable packaging scripts.
- Preserved the repository's initial README commit as the base for the project import. Gameplay remains the tested pass 07 implementation.

## 07 — Legends-inspired motion refinement

- Replaced mirrored leg swings with separate contact, push-off and recovery poses, restrained torso counter-motion, bent elbows and rolling boots for both characters.
- Baked model-specific boot contact into body height, retaining original geometry, skin weights and texture pixels.
- Matched running cadence to traversal speed and synchronized footstep effects to gait contacts.
- Preserved stride phase when changing between running, backpedaling and strafing, with short transitions and full torso compensation for the buster arm.
- Added full-cycle boot contact, aim stability, stride continuity and footstep checks. Character and combat suites and keyboard traversal pass.
- Recorded a new gameplay preview with sound and preserved the prior build in `backups/v6/`. Updated the local portable pack.

## 06 — Original Legends characters

- Imported the supplied Mega Man Volnutt and Roll Caskett archives, credited to The Models Resource submitter Xinus23 and Capcom. Retained unmodified archives and source hashes locally.
- Replaced the procedural player with textured, skinned GLB models. Preserved both original 18-joint rigs and authored twelve new movement, combat and outcome clips.
- Added title-screen Mega/Roll selection with mouse, keyboard and C shortcut, sharing the same roguelike progression and buster options.
- Layered aiming and recoil over locomotion; attached original local busters and muzzle markers to the forearm. Replaced intersecting glove geometry in playable variants.
- Rendered actual model portraits for the HUD and pause menu, including correct character names.
- Added rig, weight, animation, aiming, firing and descent-retention checks plus a six-pose render gallery.
- Preserved the audio-pass build in `backups/v5/` and updated the local portable build.

## 05 — Original music and sound

- Composed seven original cues with editable MIDI sources: title, three descents, guardian, clear and defeat. Rendered locally with GeneralUser GS 2.0.3 and FluidSynth.
- Replaced runtime tone placeholders with 29 layered effects and a stereo ruin ambience loop; added weapon variants, footsteps, jumps, landing, lock-on, robot destruction and distinct pickup feedback.
- Added music crossfades, guardian transitions, menu ducking, 3D robot effects, independent audio randomness, voice caps, reverb and a master limiter.
- Added a console-style sound menu with separate Master, Music, Effects and Ambience levels, saved separately from run records.
- Kept composition tools, renderer and SoundFont local and outside the playable content pack. Included source credits and license text.
- Added audio routing/cue/menu checks, a runtime mix capture and a soundtrack preview. Preserved the prior build in `backups/v4/`.

## 04 — Console-style UI

- Replaced the dark card layout with framed cobalt windows, a mechanical blue background, outlined lettering, segmented Life meters, and a yellow selection cursor.
- Bundled Russo One and Barlow Semi Condensed fonts with their open-font licenses.
- Drew a 32-icon equipment atlas, a Volnutt portrait, and a menu background pattern locally.
- Redesigned title, HUD, pause, Buster Parts, collection, upgrade choices, and dig results.
- Added keyboard navigation and scrollable part inspection; kept mouse and number-key shortcuts.
- Added uniform UI scaling and a widescreen safe area, and checked three window sizes.
- Added UI interaction checks and a staged render gallery that leaves player saves untouched.
- Preserved the previous version in `backups/v3/`.

## 03 — Combat and exploration

- Added committed attack windups and visible ground warnings for swings, sentry shots, charges, shockwaves, bombardment, and crossing beams.
- Gave the three guardians different attack mixes, palette variations, and an overdrive recovery transition.
- Added muzzle flashes, bolt trails, hit and kill markers, enemy flashes, knockback, recoil, impact rings, and optional camera feedback.
- Made Siege Buster wall impacts splash nearby exposed enemies while respecting solid cover.
- Added five cover arrangements and dungeon grid navigation; robots can route around obstacles and through connected doors.
- Added behavior checks for attack timing, evasions, cover, pathfinding, generation, and pause handling.
- Preserved the previous version in `backups/v2/`.

## 02 — Clean PS1 visual pass

- Added a locally authored helmet-off Volnutt fan model with blue armor, brown hair, a painted face, and a left-arm buster.
- Added five editable painted texture sources, enclosed chambers, warm lamps, ceiling beams, and new robot silhouettes.
- Preserved the original prototype in `backups/v1/`.

## 01 — First playable

- Created the original three-descent run loop, stackable relics, busters, experience, unlocks, procedural rooms, guardians, UI, sound, and local saves.

Passes 01–07 were developed locally without a repository or publishing step. In pass 08 the user explicitly authorized committing the project to Alialhashemi23/Megaman-Legends-Rogue. No hosted game deployment or release publication was requested.
